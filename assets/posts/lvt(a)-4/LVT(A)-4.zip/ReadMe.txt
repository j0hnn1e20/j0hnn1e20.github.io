--------------------------------------------------------
Tanque LVT(A)-4
Autor: Digitalmindsoft
Conversão: J0hnn1e20
--------------------------------------------------------
Mova a pasta "LVT(A)-4" para a pasta do modloader.
Substitui: Rhino
--------------------------------------------------------