Esta obra está protegida pela Lei Federal nº 9.610/1998,
Lei de Direitos Autorais, a qual regula os direitos 
relativos à criação intelectual, como obras artísticas
na República Federativa do Brasil. 
--------------------------------------------------------
Pack de Rodas SA Style v1
Autor: J0hnn1e20
--------------------------------------------------------
Use qualquer uma das rodas em seus veículos no estilo
GTA San Andreas.
--------------------------------------------------------
Esta obra está classificada como Obra de Livre Uso.

Por favor, consulte os Termos de Uso disponíveis no link
abaixo para conhecer as permissões e restrições 
relacionadas ao uso desta obra:  

https://j0hnn1e20.github.io/page/EULA.html