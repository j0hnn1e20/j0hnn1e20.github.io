Esta obra está protegida pela Lei Federal nº 9.610/1998,
Lei de Direitos Autorais, a qual regula os direitos 
relativos à criação intelectual, como obras artísticas
na República Federativa do Brasil. 
--------------------------------------------------------
Sirene 1970's
Autor: Leibe09
--------------------------------------------------------
Importe e use em seu veículo.
--------------------------------------------------------
https://linktr.ee/leibe09
https://vk.com/leibe09
https://discord.com/invite/KVUKj6YU78

Confira mais modelos em: https://j0hnn1e20.github.io/